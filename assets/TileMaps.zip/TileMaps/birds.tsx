<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="birds" tilewidth="32" tileheight="32" tilecount="680" columns="20">
 <image source="birds.png" width="644" height="1102"/>
</tileset>
