<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="background" tilewidth="32" tileheight="32" tilecount="1344" columns="42">
 <image source="background.png" width="1348" height="1044"/>
</tileset>
